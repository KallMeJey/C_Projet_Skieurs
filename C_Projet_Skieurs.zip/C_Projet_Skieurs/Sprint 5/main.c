#include "includes/ft_utils.h"

/*
	Cette fonction r�cup�re une ligne entr�e par l'utilisateur.
	[in](void)
	[out](char*) : la cha�ne de caract�re rentr�e par l'utilisateur.
*/
char	*input(void)
{
	char	*result;
	char	buffer;
	int		size;

	if (!(result = malloc(sizeof(char) * BUF_SIZE)))
		return (NULL);
	size = 0;
	// j'enregistre le caract�re actuel dans la variable buffer
	while (_read(0, &buffer, 1)) // si = 0 donc fin de lecture
	{
		if (buffer == '\n' || buffer == '\0' || buffer == EOF) // EOF = End Of Line (pour compatibilit� Windows)
		{
			result[size] = '\0';
			break ;
		}
		result[size++] = buffer;
	}
	return (result);
}

int		main(void)
{
	char *line = NULL;

	// -- initialisation
	t_run run;
	run.maxSkiers = 50;
	if (!(line = malloc(sizeof(char) * BUF_SIZE)))
		return (-1);
	if (!(run.skiers = malloc(sizeof(t_skier) * 50)))
		return (-1);
	for (int i = 0; i < run.maxSkiers; i++)
	{
		run.skiers[i].name = NULL;
		run.skiers[i].last = 0;
	}
	// -- execution
	line = input();
	while (strcmp(line, "exit"))
	{
		ft_execute(&run, line);
		line = input();
	}

	// -- fin
	free(line);
	return (0);
}
