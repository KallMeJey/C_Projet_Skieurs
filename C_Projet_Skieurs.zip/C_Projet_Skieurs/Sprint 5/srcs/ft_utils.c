#include "../includes/ft_utils.h"

/*
	Cette fonction retourne la taille d'une chaîne de caractères.
	[in](const char *str): la chaîne de caractère
	[out](size_t): la taille
*/
size_t	ft_strlen(const char *str)
{
	size_t	len;
	
	len = 0;
	while (str[len]) // = str[len] != '\0'
		len++;
	return (len);
}

/*
	Cette fonction retourne la taille d'un tableau.
	[in](const char **tab): l'adresse du tableau
	[out](size_t): la taille
*/
size_t	ft_tabsize(const char **tab)
{
	size_t	len;
	
	len = 0;
	while (tab[len]) // = tab[len] != 0
		len++;
	return (len);
}

/*
	Cette fonction exécute une commande en fonction d'une chaîne de caractères.
	[in](const t_run *run): la course
	[in](const char *line): la ligne de caractères
	[out](void)
*/
void	ft_execute(const t_run *run, const char *line)
{
	const unsigned short	c_skiers = s_count(run);
	const char 				**args = ft_split(line);

	if (!strcmp(args[0], "definir_course")) // -- commande définir course
	{
		const unsigned short doors = atoi(args[1]);
		assert(doors >= 2 && doors <= 20);
		define_run(run, doors);
	}
	 else if (!strcmp(args[0], "inscrire_skieur")) // -- commande inscrire skieur
	{
		const char	*name = args[1];
		const char	*country = args[2];
		run->skiers[c_skiers] = *add(run, name, country, 101 + c_skiers);
	}
	else if (!strcmp(args[0], "afficher_skieurs")) // -- commande affichage des skieurs
		show_all(run);
	else if (!strcmp(args[0], "enregistrer_temps")) // -- commande enregistrer temps
	{
		const double			time	= strtod(args[1], NULL);
		assert(time >= 0);
		const unsigned short 	step	= atoi(args[2]);
		assert(step >= 0 && step <= 18);
		const unsigned short	bib		= atoi(args[3]);
		assert(bib >= 101 && bib <= 101 + run->maxSkiers);
		save_run(run, step, time, get(run, bib));
	}
	else if (!strcmp(args[0], "disqualification")) // -- commande disqualification
	{
		const unsigned short step	= atoi(args[1]);
		assert(step >= 0 && step <= 18);
		const unsigned short bib	= atoi(args[2]);
		assert(bib >= 101 && bib <= 101 + run->maxSkiers);
		eliminate(run, step, get(run, bib));	
	}
	else if (!strcmp(args[0], "afficher_temps")) // -- commande afficher temps
	{
		const unsigned short bib		= atoi(args[1]);
		assert(bib >= 101 && bib <= 101 + run->maxSkiers);
		show(run, *get(run, bib));
	}
	else if (!strcmp(args[0], "afficher_classement")) // -- commande afficher classement
	{
		const unsigned short step	= atoi(args[1]);
		assert(step >= 0 && step <= 18);
		show_top(run, step);
	}
}

void	ft_quit()
{
	exit(0);
}
