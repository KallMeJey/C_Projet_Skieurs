#include "../includes/ft_utils.h"

void    define_run(t_run *run, const unsigned short n)
{
    // -- enregistrer le nombre de portes
    run->steps = n;
}

void    show_top(const t_run *run, const unsigned short step)
{
    t_skier     *sorted;
    t_skier     tmp;
    short       find;
    int         max;
    int         i;

    // -- début de la copie des skieurs
    if (!(sorted = malloc(sizeof(t_skier) * s_count(run))))
        return ;
    i = -1;
    while (run->skiers[++i].name)
        sorted[i] = run->skiers[i];
    // -- fin de copie

    find = 1;
    max = s_count(run);
    i = 0;
    
    // -- de l'algorithme de tri
    while (find)
    {
        find = 0;
        i = 0;
        while (i < max - 1)
        {
            // -- si le temps total du skieur actuel est supérieur au prochain
            if (s_total(sorted[i], step) > s_total(sorted[i + 1], step))
            {
                // -- on les échange
                tmp = sorted[i];
                sorted[i] = sorted[i + 1];
                sorted[i + 1] = tmp;
                find = 1;
            }   
            i++;
        }
        // -- à chaque tour de boucle on enlève une possibilité
        max--;
    }
    i = -1;
    // -- début de l'affichage des skieurs
    while (sorted[++i].name)
    {
		if (!(sorted[i].bib >= 101 && sorted[i].bib <= 101 + run->maxSkiers))
			continue ;
        else if (sorted[i].records[step].verif == '-')
            continue ;
        printf("%d %d ", step, sorted[i].bib);
        printf("%s ", sorted[i].name);
		printf("%s ", sorted[i].country);
        printf("%.2f\n", s_total(sorted[i], step));
    }
    // -- fin de l'affichage
	free(sorted);
}

t_skier *sorted_eliminated(t_run *run)
{
	t_skier     *sorted;
	t_skier     tmp;
	short       find;
	int         max;
	int         i;

	// -- début de la copie des skieurs
	max = 0;
	i = -1;
	while (run->skiers[++i].name)
		if (run->skiers[i].eliminated)
			max++;
	if (!(sorted = malloc(sizeof(t_skier) * max)))
		return (NULL);
	max = 0;
	i = -1;
	while (run->skiers[++i].name)
		if (run->skiers[i].eliminated)
			sorted[max++] = run->skiers[i];
	// -- fin de copie
	--max;
	find = 1;
	i = 0;
	// -- de l'algorithme de tri
	while (find)
	{
		find = 0;
		i = 0;
		while (i < max - 1)
		{
			tmp = sorted[i];
			// -- si le temps total du skieur actuel est supérieur au prochain
			if (tmp.last < sorted[i + 1].last)
			{
				// -- on les échange
				sorted[i] = sorted[i + 1];
				sorted[i + 1] = tmp;
				find = 1;
			}
			i++;
		}
		// -- à chaque tour de boucle on enlève une possibilité
		max--;
	}
	return (sorted);
}

void    show_eliminated(const t_run *run)
{
	t_skier *skiers = sorted_eliminated(run);
	unsigned short max = 0;
	unsigned short i;
	while (skiers[max++].name);
	i = 0;
    // -- début de l'affichage des skieurs éliminés
    while (i < max - 1)
    {
		printf("disqualifie %d ", skiers[i].bib);
		printf("%s ", skiers[i].name);
		printf("%s\n", skiers[i++].country);
	}
    // -- fin de l'affichage
}

void    save_run(const  t_run *run, const unsigned short step, const double time, t_skier *skier)
{
    // -- si le skieur est éliminé, ça ne sert à rien de continuer
    if (skier->eliminated)
        return ;
    skier->records[step].verif = '+';
    skier->records[step].time = time;
    // -- si la porte passée est la dernière, on vérifie si la course est terminée
    if (step == run->steps)
        ft_check(run, step);
}
