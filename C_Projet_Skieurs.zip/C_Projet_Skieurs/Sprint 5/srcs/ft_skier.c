#include "../includes/ft_utils.h"

t_skier *add(const t_run *run, const char *name, const char *country, const unsigned short bib)
{
    assert(bib >= 101 && bib <= 101 + run->maxSkiers);
    t_skier *skier;
    short    i;

    if (!(skier = (t_skier*)malloc(sizeof(t_skier))))
        return (NULL);
    skier->name = name;
	skier->country = country;
	skier->bib = bib;
	skier->eliminated = 0;
    // -- chaque skieur aura autant de places d'enregistrements que de porte
    if (!(skier->records = (t_record*)malloc(sizeof(t_record) * (run->steps + 1))))
        return (NULL);
    i = -1;
    while (++i < run->steps + 1)
    {
        skier->records[i].verif = '-';
        skier->records[i].step = i;
        skier->records[i].time = 0;
    }
    printf("inscription dossard %d\n", bib);
    return (skier);
}

t_skier *get(const t_run *run, const unsigned short bib)
{
    assert(bib >= 101 && bib <= 101 + run->maxSkiers);
    t_skier *skier = NULL;
    short   i;

    i = -1;
    while (run->skiers[++i].name)
        if (run->skiers[i].bib == bib)
        {
            skier = &run->skiers[i];
            break ;
        }
    return (skier);
}

short  s_count(const t_run *run)
{
	short  i;

	i = 0;
	while (run->skiers[i].name != NULL)
		i++;
    return (i);
}

double  s_total(const t_skier skier, unsigned short step)
{
    assert(skier.records[step].step <= step);
    if (skier.records[0].verif == '-') // n'a pas passé la porte
        return (0);
    double total = skier.records[step--].time - skier.records[0].time;
    return (total < 0 ? -total : total);
}

void    ft_check(const t_run *run, const unsigned short step)
{
    size_t  i;
    size_t  count;
    size_t  not;

    i = 0;
    count = 0;
    not = 0;
    while (run->skiers[i].name)
    {
        if (run->skiers[i].eliminated) // -- on compte le nombre de skieurs éliminé
            count++;
        else if (run->skiers[i].records[step].verif != '+') // -- on compte le nombre de skieurs n'ayant pas passé la porte
            not++;
        i++;
    }
    // -- si il y a autant de skieurs éliminés que de skieurs enregistré ou que tout le monde a passé la porte
    if (count == s_count(run) || !not)
    {
        printf("detection_fin_course\n");
        show_top(run, step);
        show_eliminated(run);
        ft_quit();
    }
}

void    eliminate(const t_run *run, const unsigned int step, t_skier *skier)
{
    assert(step <= run->steps);
    skier->eliminated = 1;
    skier->records[step].verif = '-';
	skier->last = step;
    // ft_check(run, step); // -- à chaque élimination on vérifie si la course est finie
}

void    show(const t_run *run, t_skier skier)
{
	while ((*skier.records).verif != '-' && (((*skier.records).step >= 0) && (*skier.records).step <= run->steps + 1))
	{
		printf("%d %d %.2f\n", (*skier.records).step, skier.bib, (*skier.records).time); 
		(*skier.records++); // -- je me permets d'incrémenter le pointeur car skier est une variable locale
	}
}

void    show_all(const t_run *run)
{
    short  i;

    i = -1;
    while (run->skiers[++i].name)
    {
        printf("%s ", run->skiers[i].name);
        printf("%s ", run->skiers[i].country);
        printf("%d\n", run->skiers[i].bib);
    }
}
