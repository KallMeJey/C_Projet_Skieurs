#ifndef FT_SKIER_H
# define FT_SKIER_H 
# include "ft_utils.h"

/*
	Cette fonction crée un nouveau skieur.
	[in](const t_run *run): la course
	[in](const char *name): le nom
	[in](const char *country): le pays
	[in](const unsigned short bib): le dossard
	[out](t_skier): le skieur créé
*/
t_skier		*add(const t_run *run, const char *name, const char *country, const unsigned short bib);

/*
	Cette fonction récupère un skieur en fonction de son dossard.
	[in](const t_run *run): la course
	[in](const unsigned short bib): le dossard
	[out](t_skier): le skieur créé
*/
t_skier     *get(const t_run *run, const unsigned short bib);

/*
	Cette fonction elimine un skieur à une porte donnée et effectue une vérification de fin.
	[in](const t_run *run): la course
	[in](const unsigned short step): la porte
	[in](t_skier *skier): le skieur a éliminer
	[out](void)
*/
void		eliminate(const t_run *run, const unsigned short step, t_skier *skier);

/*
	Cette fonction affiche des information sur un skieur.
	[in](const t_run *run): la course
	[in](t_skier skier): le skieur
	[out](void)
*/
void		show(const t_run *run, t_skier skier);

/*
	Cette fonction affiche tous les skieurs.
	[in](const t_run *run): la course
	[out](void)
*/
void		show_all(const t_run *run);

#endif
