#ifndef FT_UTILS_H
# define FT_UTILS_H 
# include <assert.h>
# include <limits.h>
# include <io.h>
# include <string.h>
# include <stdlib.h>
# include <stdio.h>
# define BUF_SIZE 1024

/* Ce type correspond à un enregistrement. */
typedef struct	s_record
{
	char		verif; // le skieur a-t-il réussi
	int			step; // la porte
	double		time; // le temps total
}				t_record;

/* Ce type correspond à un skieur. */
typedef struct	s_skier
{
	char		*name; // le nom
	char		*country; // le pays
	int			bib; // le dossard
	int			eliminated; // un booléen
	int			last;
	t_record	*records; // la liste des enregistrements
}				t_skier;

/* Ce type correspond à une course. */
typedef struct s_run
{
	unsigned short	maxSkiers; // le nombre de skieurs maximum
	unsigned short	steps; // le nombre de porte
	t_skier     	*skiers; // le "tableau" des skieurs
}				t_run;

# include "ft_skier.h"
# include "ft_run.h"

/*
	Cette fonction transforme une chaîne de caractères espacée par des (' ', '\t', '\n') en un tableau de mots.
	[in](const char *line): la chaine de caractères
	[out](char**): le tableau de mots
*/
char	**ft_split(char *line);

/*
	Cette fonction retourne la taille d'un tableau.
	[in](const char **tab): l'adresse du tableau
	[out](size_t): la taille
*/
size_t	ft_tabsize(const char **tab);

/* 
	Cette fonction compte la taille d'une chaîne de caractères.
	[in](const char *str): la chaîne de caractère
	[out](size_t): la taille
*/
size_t	ft_strlen(const char *str);

/*
	Cette fonction compte le nombre de skieurs.
	[in](const t_run *run): la course
	[out](short): le nombre de skieurs	
*/
short  s_count(const t_run *run);

/*
	Cette fonction retourne le temps total parcouru par un skieur.
	[in](const t_skier skier): le skieur
	[in](const char *line): la porte actuelle
	[out](double): le temps total
*/
double	s_total(const t_skier skier, const unsigned short step);

/*
	Cette fonction vérifie si à une porte donnée la course est finie.
	[in](const t_run *run): la course
	[in](const char *line): la porte actuelle
	[out](void)
*/
void    ft_check(const t_run *run, const unsigned short step);

/*
	Cette fonction exécute une commande en fonction d'une chaîne de caractères.
	[in](const t_run *run): la course
	[in](const char *line): la ligne de caractères
	[out](void)
*/
void	ft_execute(const t_run *run, const char *line);

/*
	Cette fonction quitte le programme.
	[out](void)
*/
void	ft_quit();

#endif
