#ifndef FT_RUN_H
# define FT_RUN_H  
# include "ft_utils.h"

/*
	Cette fonction définie le nombre de porte dans le parcours.
	[in](t_run *run): la course
	[in](const unsigned short n): le nombre de portes
	[out](void)
*/
void	define_run(t_run *run, const unsigned short n);

/*
	Cette fonction affiche le classement à une porte donnée.
	[in](t_run *run): la course
	[in](const unsigned short step): la porte
	[out](void)
*/
void	show_top(const t_run *run, const unsigned short step);

t_skier	*sorted_eliminated(t_run *run);

/*
	Cette fonction affiche tous les skieurs éliminés.
	[in](t_run *run): la course
	[out](void)
*/
void    show_eliminated(const t_run *run);

/*
	Cette fonction enregistre le temps parcouru par un skieur à une porte donnée.
	[in](t_run *run): la course
	[in](const unsigned short step): la porte
	[in](const double time): la porte
	[in](t_skier *skier): le skieur
	[out](void)
*/
void    save_run(t_run *run, const unsigned short step, const double time, t_skier *skier);

#endif
