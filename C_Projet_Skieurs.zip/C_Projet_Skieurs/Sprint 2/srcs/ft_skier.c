#include "../includes/ft_utils.h"

t_skier *add(const t_run *run, const char *name, const char *country, const unsigned short bib)
{
    assert(bib >= 101 && bib <= 151);
    t_skier *skier;
    short    i;

    if (!(skier = (t_skier*)malloc(sizeof(t_skier))))
        return (NULL);
    skier->name = name;
	skier->country = country;
	skier->bib = bib;
	skier->eliminated = 0;
    // -- chaque skieur aura autant de places d'enregistrements que de porte
    if (!(skier->records = (t_record*)malloc(sizeof(t_record) * (run->steps + 1))))
        return (NULL);
    i = -1;
    while (++i < run->steps + 1)
    {
        skier->records[i].verif = '-';
        skier->records[i].step = i;
        skier->records[i].time = 0;
    }
    printf("inscription dossard %d\n", bib);
    return (skier);
}

t_skier *get(const t_run *run, const unsigned short bib)
{
    assert(bib >= 101 && bib <= 151);
    t_skier *skier = NULL;
    short   i;

    i = -1;
    while (run->skiers[++i].name)
        if (run->skiers[i].bib == bib)
        {
            skier = &run->skiers[i];
            break ;
        }
    return (skier);
}

short  s_count(const t_run *run)
{
	short  i;

	i = 0;
	while (run->skiers[i].name != NULL)
		i++;
    return (i);
}

void    show(const t_run *run, t_skier skier)
{
    while ((*skier.records).verif == '+' && (((*skier.records).step >= 0) && (*skier.records).step <= run->steps + 1))
    {
		printf("%d %d %.2f\n", (*skier.records).step, skier.bib, (*skier.records).time);
		*skier.records++; // -- je me permets d'incrémenter le pointeur car skier est une variable locale
    }
}

void    show_all(const t_run *run)
{
    short  i;

    i = -1;
    while (run->skiers[++i].name)
    {
        printf("%s ", run->skiers[i].name);
        printf("%s ", run->skiers[i].country);
        printf("%d\n", run->skiers[i].bib);
    }
}
