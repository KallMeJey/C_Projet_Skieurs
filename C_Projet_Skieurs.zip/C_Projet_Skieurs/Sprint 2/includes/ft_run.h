#ifndef FT_RUN_H
# define FT_RUN_H  
# include "ft_utils.h"

/* Cette fonction définie le nombre de porte dans le parcours. */
void	define_run(t_run *run, const unsigned short n);

/* Cette fonction enregistre le temps parcouru par un skieur à une porte donnée. */
void    save_run(const t_run *run, const unsigned short step, const double time, t_skier *skier);

#endif
