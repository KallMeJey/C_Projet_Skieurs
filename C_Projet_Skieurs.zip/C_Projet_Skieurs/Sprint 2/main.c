#include "includes/ft_utils.h"

char	*input()
{
	char	*result;
	char	buffer;
	int		size;

	if (!(result = malloc(sizeof(char) * BUF_SIZE)))
		return (NULL);
	size = 0;
	while (_read(0, &buffer, 1))
	{
		if (buffer == '\n' || buffer == '\0' || buffer == EOF)
		{
			result[size] = '\0';
			break ;
		}
		result[size++] = buffer;
	}
	return (result);
}

int		main(void)
{
	char *line = NULL;

	t_run run;
	define_run(&run, 0);
	if (!(line = malloc(sizeof(char) * BUF_SIZE)))
		return (-1);
	if (!(run.skiers = malloc(sizeof(t_skier) * 50)))
		return (-1);
	for (int i = 0; i < 50; i++)
		run.skiers[i].name = NULL;
	line = input();
	while (strcmp(line, "exit"))
	{
		ft_execute(&run, line);
		line = input();
	}
	free(line);
	return (0);
}
