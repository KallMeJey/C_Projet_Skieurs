#ifndef FT_SKIER_H
# define FT_SKIER_H 
# include "ft_utils.h"

/* Cette fonction crée un nouveau skieur. */
t_skier		*add(const t_run *run, const char *name, const char *country, const unsigned short bib);

/* Cette fonction récupère un skieur en fonction de son dossard. */
t_skier     *get(const t_run *run, const unsigned short bib);

/* Cette fonction elimine un skieur à une porte donnée et effectue
   une vérification de fin. */
void		eliminate(const t_run *run, const unsigned short step, t_skier *skier);

/* Cette fonction affiche des information sur un skieur. */
void		show(const t_run *run, t_skier skier);

/* Cette fonction affiche tous les skieurs. */
void		show_all(const t_run *run);

#endif
