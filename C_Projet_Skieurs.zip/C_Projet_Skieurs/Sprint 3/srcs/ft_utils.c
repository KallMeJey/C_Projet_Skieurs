#include "../includes/ft_utils.h"

size_t	ft_strlen(const char *str)
{
	size_t	len;
	
	len = 0;
	while (str[len]) // = str[len] != '\0'
		len++;
	return (len);
}

size_t	ft_tabsize(const char **tab)
{
	size_t	len;
	
	len = 0;
	while (tab[len]) // = tab[len] != 0
		len++;
	return (len);
}

void	ft_execute(const t_run *run, const char *line)
{
	char 			**args;
	unsigned short	c_skiers;

	c_skiers = s_count(run);
	args = ft_split(line);
	if (!strcmp(args[0], "definir_course")) // -- commande définir course
	{
		unsigned short doors = atoi(args[1]);
		assert(doors >= 2 && doors <= 20);
		define_run(run, doors);
	}
	 else if (!strcmp(args[0], "inscrire_skieur")) // -- commande inscrire skieur
	{
		char	*name = args[1];
		char	*country = args[2];
		run->skiers[c_skiers] = *add(run, name, country, 101 + c_skiers);
	}
	else if (!strcmp(args[0], "afficher_skieurs")) // -- commande affichage des skieurs
		show_all(run);
	else if (!strcmp(args[0], "enregistrer_temps")) // -- commande enregistrer temps
	{
		double			time	= strtod(args[1], NULL);
		unsigned short 	step	= atoi(args[2]);
		unsigned short	bib		= atoi(args[3]);
		assert(time >= 0);
		assert(step >= 0 && step <= 18);
		assert(bib >= 101 && bib <= 151);
		save_run(run, step, time, get(run, bib));
	}
	else if (!strcmp(args[0], "disqualification")) // -- commande disqualification
	{
		unsigned short step	= atoi(args[1]);
		unsigned short bib	= atoi(args[2]);
		assert(step >= 0 && step <= 18);
		assert(bib >= 101 && bib <= 151);
		eliminate(run, step, get(run, bib));	
	}
	else if (!strcmp(args[0], "afficher_temps")) // -- commande afficher temps
	{
		unsigned short bib = atoi(args[1]);
		assert(bib >= 101 && bib <= 151);
		show(run, *get(run, bib));
	}
}

void	ft_quit()
{
	exit(0);
}
