#include "../includes/ft_utils.h"

void    define_run(t_run *run, const unsigned short n)
{
    // -- enregistrer le nombre de portes
    run->steps = n;
}

void    save_run(const t_run *run, const unsigned short step, const double time, t_skier *skier)
{
    // -- si le skieur est éliminé, ça ne sert à rien de continuer
    if (skier->eliminated)
        return ;
    skier->records[step].verif = '+';
    skier->records[step].time = time;
}
