#ifndef FT_SKIER_H
# define FT_SKIER_H 
# include "ft_utils.h"

/* Cette fonction crée un nouveau skieur. */
t_skier		*add(const t_run *run, const char *name, const char *country, const unsigned short bib);

/* Cette fonction affiche tous les skieurs. */
void		show_all(const t_run *run);

#endif
