#ifndef FT_UTILS_H
# define FT_UTILS_H 
# include <assert.h>
# include <limits.h>
# include <io.h>
# include <string.h>
# include <stdlib.h>
# include <stdio.h>
# define BUF_SIZE 1024

/* Ce type correspond à un enregistrement. */
typedef struct	s_record
{
	char		verif; // le skieur a-t-il réussi
	int			step; // la porte
	double		time; // le temps total
}				t_record;

/* Ce type correspond à un skieur. */
typedef struct	s_skier
{
	char		*name; // le nom
	char		*country; // le pays
	int			bib; // le dossard
	int			eliminated; // un booléen
	t_record	*records; // la liste des enregistrements
}				t_skier;

typedef struct s_run
{
	unsigned short	steps; // le nombre de porte
	t_skier     	*skiers; // le "tableau" des skieurs
}				t_run;

# include "ft_skier.h"

/* Cette fonction transforme une chaîne de caractères espacée par des (' ', '\t', '\n') en un tableau de mots. */
char	**ft_split(const char *line);

/* Cette fonction compte le nombre d'occurences dans un tableau. */
size_t	ft_tabsize(const char **tab);

/* Cette fonction compte la taille d'une chaîne de caractères. */
size_t	ft_strlen(const char *str);

/* Cette fonction compte le nombre de skieurs. */
unsigned short  s_count(const t_run *run);

/* Cette fonction execute une commande en fonction d'une chaîne de caractères. */
void	ft_execute(const t_run *run, const char *line);

/* Cette fonction quitte le programme. */
void	ft_quit();

#endif
