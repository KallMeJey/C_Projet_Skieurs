#include "../includes/ft_utils.h"

size_t	ft_strlen(const char *str)
{
	size_t	len;
	
	len = 0;
	while (str[len]) // = str[len] != '\0'
		len++;
	return (len);
}

size_t	ft_tabsize(const char **tab)
{
	size_t	len;
	
	len = 0;
	while (tab[len]) // = tab[len] != 0
		len++;
	return (len);
}

void	ft_execute(const t_run *run, const char *line)
{
	char 			**args;
	unsigned short	c_skiers;

	c_skiers = s_count(run);
	args = ft_split(line);
	if (!strcmp(args[0], "inscrire_skieur")) // -- commande inscrire skieur
	{
		char	*name = args[1];
		char	*country = args[2];
		run->skiers[c_skiers] = *add(run, name, country, 101 + c_skiers);
	}
	else if (!strcmp(args[0], "afficher_skieurs")) // -- commande affichage des skieurs
		show_all(run);
}

void	ft_quit()
{
	exit(0);
}
