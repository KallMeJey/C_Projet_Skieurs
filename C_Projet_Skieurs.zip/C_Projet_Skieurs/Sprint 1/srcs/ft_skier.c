#include "../includes/ft_utils.h"

t_skier *add(const t_run *run, const char *name, const char *country, const unsigned short bib)
{
    assert(bib >= 101 && bib <= 151);
    t_skier *skier;

    if (!(skier = (t_skier*)malloc(sizeof(t_skier))))
        return (NULL);
    skier->name = name;
	skier->country = country;
	skier->bib = bib;
	skier->eliminated = 0;
    printf("inscription dossard %d\n", bib);
    return (skier);
}

unsigned short	s_count(const t_run *run)
{
	short  i;

	i = 0;
	while (run->skiers[i].name != NULL)
		i++;
	return (i);
}

void    show_all(const t_run *run)
{
    short  i;

    i = -1;
    while (run->skiers[++i].name)
    {
        printf("%s ", run->skiers[i].name);
        printf("%s ", run->skiers[i].country);
        printf("%d\n", run->skiers[i].bib);
    }
}
